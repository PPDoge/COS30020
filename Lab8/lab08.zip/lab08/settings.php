<?php
$host = "feenix-mariadb.swin.edu.au";
$user = "s104188405";
$pswd = "110802";
$dbnm = "s104188405_db";
?>