<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="description" content="Web application development" />
    <meta name="keywords" content="PHP" />
    <meta name="author" content="Nguyen Duy Anh Tu" />
    <title>TITLE</title>
</head>

<body>
    <h1>Web Programming Form - Lab 5</h1>
    <form action="shoppingsave.php" method="post">
        <p>Enter item name: <input name="item"></p>
        <p>Enter quantity: <input name="qty"></p>
        <input type="submit" value="Submit" />
    </form>
</body>

</html>